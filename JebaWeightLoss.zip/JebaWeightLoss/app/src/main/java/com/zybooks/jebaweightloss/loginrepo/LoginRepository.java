package com.zybooks.jebaweightloss.loginrepo;

import android.content.Context;

public class LoginRepository {
    private static LoginRepository repo;
    private static LoginDatabase db;
    public static LoginRepository getInstance(Context context){
        if (repo == null) {
            repo = new LoginRepository(context);
        }
        return repo;
    }

    private LoginRepository(Context context){
        db = new LoginDatabase(context);
    }

    public LoginDatabase getDB(){
        return db;
    }
}
