package com.zybooks.jebaweightloss.recordmodel;

import java.util.Date;

public class Record {
    private long mID;
    private double mWeight;
    private Date mDate;


    public Record(double mWeight) {
        this.mWeight = mWeight;
    }

    public Record(long id, double mWeight, Date date) {
        this.mWeight = mWeight;
        this.mID  = id;
        this.mDate = date;
    }

    public long getID() {
        return mID;
    }

    public void setID(long mID) {
        this.mID = mID;
    }

    public double getWeight() {
        return mWeight;
    }

    public void setWeight(double mWeight) {
        this.mWeight = mWeight;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date mDate) {
        this.mDate = mDate;
    }
}
