package com.zybooks.jebaweightloss;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.zybooks.jebaweightloss.recordmodel.Record;
import com.zybooks.jebaweightloss.recordrepo.RecordRepository;

import java.util.List;

public class RecordAdapter extends BaseAdapter {

    private final Activity activity;
    private RecordRepository repo;

    public RecordAdapter(Activity activity, RecordRepository repo) {
        super();
        this.activity = activity;
        this.repo = repo;
    }

    static class ViewHolder {
        public long id;
        public TextView weight;
        public TextView date;
    }



    @Override
    public int getCount() {
        return repo.getRecords().size();
    }

    @Override
    public Record getItem(int i) {
        return repo.getRecords().get(i);
    }

    @Override
    public long getItemId(int i) {
        return ((Record) getItem(i)).getID();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;

        if (view == null) {
            view = LayoutInflater.from(activity).inflate(R.layout.record_item, viewGroup, false);
            holder = new ViewHolder();
            holder.weight = (TextView) view.findViewById(R.id.list_item_weight);
            holder.date = (TextView) view.findViewById(R.id.list_item_date);

            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }

        Record record = repo.getRecords().get(i);
        holder.id = record.getID();
        holder.weight.setText(String.valueOf(record.getWeight()));
        holder.date.setText(String.valueOf(record.getDate()));

        return view;
    }
}
