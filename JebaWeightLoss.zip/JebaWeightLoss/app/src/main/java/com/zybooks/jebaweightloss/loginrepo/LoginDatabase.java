package com.zybooks.jebaweightloss.loginrepo;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.zybooks.jebaweightloss.loginmodel.Login;

public class LoginDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "logins.db"; // FIXME: Use same database for all tables
    private static final int VERSION=1;
    private static SQLiteDatabase writeable;

    public LoginDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
        writeable = getWritableDatabase();
    }

    private static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_EMAIL = "email";
        private static final String COL_PASSWORD = "password";
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_EMAIL + " text, " +
                LoginTable.COL_PASSWORD + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    public long addLogin(String email, String password){

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_EMAIL, email);
        values.put(LoginTable.COL_PASSWORD, password);

        return writeable.insert(LoginTable.TABLE, null, values);

    }

    public Login getLogin(String email, String password){
        String[] columns = new String[] {
                LoginTable.COL_EMAIL,
                LoginTable.COL_PASSWORD
        };

        String whereClause = LoginTable.COL_EMAIL + " = ? AND " + LoginTable.COL_PASSWORD + " = ? ";
        String[] whereArgs = new String[]{
                email,
                password
        };
        Cursor c = writeable.query(LoginTable.TABLE, columns, whereClause, whereArgs, null, null, null );

        try {
            if (c.moveToFirst()) {
                @SuppressLint("Range") String emailValue = c.getString(c.getColumnIndex(LoginTable.COL_EMAIL));
                Login login = new Login(email, password);
                return login;
            } else {
                return null;
            }
        } catch (Exception e){
            Log.d(TAG, "Error while getting user");
        } finally {
            if (c!=null && !c.isClosed()){
                c.close();
            }
        }
        return null;
    }



}
