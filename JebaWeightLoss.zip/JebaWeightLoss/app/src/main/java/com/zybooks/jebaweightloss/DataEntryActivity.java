package com.zybooks.jebaweightloss;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.Manifest;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.jebaweightloss.recordrepo.RecordRepository;
import com.zybooks.jebaweightloss.recordviewmodel.RecordListViewModel;

import java.util.List;
import com.zybooks.jebaweightloss.recordmodel.Record;

public class DataEntryActivity extends AppCompatActivity{

    private RecordListViewModel mViewModel;
    private ListView mListView;
    private RecordAdapter mAdapter;
    private int selected = -1;
    private final int PERMISSION_REQUEST_SEND_SMS=0;
    private final String phoneNo = "07123456789";
    private String smsMessage = "Thanks for entering your weight today. Keep up the progress!";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_data_entry);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mViewModel = new RecordListViewModel(getApplication());
        mListView = findViewById(R.id.weights);
        mListView.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        mAdapter = new RecordAdapter(this, RecordRepository.getInstance(getApplicationContext()));
        mListView.setAdapter(mAdapter);

        Activity act = this;
        EditText editable = findViewById(R.id.weight);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // unselect previous selected one
                if (selected >= 0) {
                    parent.getChildAt(selected).setBackgroundColor(Color.TRANSPARENT);
                }
                //toggle
                if (selected == position){
                    selected = -1;
                    editable.setText("");
                } else {
                    view.setBackgroundColor(Color.LTGRAY);
                    selected = position;
                    editable.setText(String.valueOf(mAdapter.getItem(selected).getWeight()));
                }

            }
        });
    }

    public void onDelete(View view) {
        if (selected < 0){
            return;
        }
        long id = mAdapter.getItem(selected).getID();
        mViewModel.deleteRecordById(id);
        mAdapter.notifyDataSetChanged();
    }

    public void onEdit(View view){
        if (selected < 0){
            return;
        }
        long id = mAdapter.getItem(selected).getID();

        EditText weightEditText = (EditText) findViewById(R.id.weight);
        String weightText = String.valueOf(weightEditText.getText());
        double weight = Double.parseDouble(weightText);

        mViewModel.editRecordById(id, weight);
        mAdapter.notifyDataSetChanged();
    }

    public void onAdd(View view) {

        EditText weightEditText = (EditText) findViewById(R.id.weight);
        String weightText = String.valueOf(weightEditText.getText());
        double weight = Double.parseDouble(weightText);

        mViewModel.addRecord(weight);
        mAdapter.notifyDataSetChanged();

        sendSMS();
    }

    private void sendSMS(){
        SmsManager smsManager = SmsManager.getDefault();
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {

                // Can  show message later
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        PERMISSION_REQUEST_SEND_SMS);
            }
        } else {
            sendMessageAfterPermissionsGranted(phoneNo, smsMessage);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_SEND_SMS) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendMessageAfterPermissionsGranted(phoneNo, smsMessage);
            } else {
                Toast.makeText(getApplicationContext(),
                        "SMS failed", Toast.LENGTH_LONG).show();
                return;
            }
        }

    }

    private void sendMessageAfterPermissionsGranted(String number, String message){
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(number, null, message, null, null);
        Toast.makeText(getApplicationContext(), "SMS sent successfully.",
                Toast.LENGTH_LONG).show();
    }
}

