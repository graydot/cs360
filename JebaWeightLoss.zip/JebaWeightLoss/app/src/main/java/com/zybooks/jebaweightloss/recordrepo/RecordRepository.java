package com.zybooks.jebaweightloss.recordrepo;

import android.content.Context;

import com.zybooks.jebaweightloss.R;
import com.zybooks.jebaweightloss.recordmodel.Record;

import java.util.ArrayList;
import java.util.List;

public class RecordRepository {
    private static RecordRepository repo;
    private static RecordDatabase db;
    private List<Record> records;

    public static RecordRepository getInstance(Context context) {
        if (repo == null) {
            repo = new RecordRepository(context);
        }
        return repo;
    }

    private RecordRepository(Context context) {
        db = new RecordDatabase(context);
        refreshRecords();
    }

    private void refreshRecords(){
        records = db.getRecords();
    }
    public Record addRecord(double weight) {
        Record record = db.addRecord(weight);
        refreshRecords();
        return record;
    }

    public Record getRecord(long id) {
        return db.getRecord(id);
    }

    public List<Record> getRecords() {
        return records;
    }

    public void deleteRecord(long id){
        db.deleteRecord(id);
        refreshRecords();
    }

    public void editRecord(long id, double weight){
        db.editRecord(id, weight);
        refreshRecords();
    }
}
