package com.zybooks.jebaweightloss.loginmodel;

public class Login {


    private long mID;
    private String mEmail;
    private String mPassword; // FIXME: prototype password storage. Use salted bcrypted hash

    public Login(String email, String password) {
        this.mEmail = email;
        this.mPassword = password;
    }

    public long getID() {
        return mID;
    }

    public void setID(long mID) {
        this.mID = mID;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        this.mEmail = email;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        this.mPassword = password;
    }
}
