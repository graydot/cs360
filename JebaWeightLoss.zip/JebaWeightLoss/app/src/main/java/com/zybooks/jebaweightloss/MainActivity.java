package com.zybooks.jebaweightloss;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.jebaweightloss.loginmodel.Login;
import com.zybooks.jebaweightloss.loginrepo.LoginDatabase;
import com.zybooks.jebaweightloss.loginrepo.LoginRepository;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


    public void onLogin(View view) {
        EditText emailText = (EditText) findViewById(R.id.email);
        EditText passwordText = (EditText) findViewById(R.id.password);

        String email = String.valueOf(emailText.getText()).trim();
        String password = String.valueOf(passwordText.getText()).trim();

        if (email.isEmpty() || password.isEmpty()) {
            return;
        }

        LoginRepository repo = LoginRepository.getInstance(getApplicationContext());
        LoginDatabase db = repo.getDB();
        Login login = db.getLogin(email, password);

        if (login == null) {
            Toast.makeText(this, "Incorrect user details!", Toast.LENGTH_LONG).show();
        } else {
            startActivity(new Intent(this, DataEntryActivity.class));
        }
    }

    public void onSignup(View view) {
        EditText emailText = (EditText) findViewById(R.id.email);
        EditText passwordText = (EditText) findViewById(R.id.password);

        String email = String.valueOf(emailText.getText()).trim();
        String password = String.valueOf(passwordText.getText()).trim();

        if (email.isEmpty() || password.isEmpty()) {
            return;
        }

        LoginRepository repo = LoginRepository.getInstance(getApplicationContext());
        LoginDatabase db = repo.getDB();
        Login login = db.getLogin(email, password);

        if (login == null) {
            long id = db.addLogin(email, password);
            Toast.makeText(this, "User created. You can now login", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, "Sorry, user already exists!", Toast.LENGTH_LONG).show();
        }

    }


}