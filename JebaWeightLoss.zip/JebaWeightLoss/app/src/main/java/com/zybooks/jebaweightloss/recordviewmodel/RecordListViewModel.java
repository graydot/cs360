package com.zybooks.jebaweightloss.recordviewmodel;

import android.app.Application;

import com.zybooks.jebaweightloss.loginmodel.Login;
import com.zybooks.jebaweightloss.recordrepo.RecordRepository;
import com.zybooks.jebaweightloss.recordmodel.Record;


import java.util.List;

public class RecordListViewModel {
    private final RecordRepository repo;

    public RecordListViewModel(Application application) {
        repo = RecordRepository.getInstance(application.getApplicationContext());
    }

    public List<Record> getRecords() {
        return repo.getRecords();
    }

    public void addRecord(double weight) {
        repo.addRecord(weight);
    }

    public void deleteRecordById(long id){
        repo.deleteRecord(id);
    }

    public void editRecordById(long id, double weight){
        repo.editRecord(id, weight);
    }


}
