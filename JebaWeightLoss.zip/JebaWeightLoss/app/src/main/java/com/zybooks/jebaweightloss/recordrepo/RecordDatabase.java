package com.zybooks.jebaweightloss.recordrepo;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zybooks.jebaweightloss.loginmodel.Login;
import com.zybooks.jebaweightloss.loginrepo.LoginDatabase;
import com.zybooks.jebaweightloss.recordmodel.Record;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class RecordDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weights.db";
    private static final int VERSION=1;
    private static SQLiteDatabase writeable;

    public RecordDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
        writeable = getWritableDatabase();
    }

    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_WEIGHT = "weight";
        private static final String COL_DATE = "date";
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                RecordDatabase.WeightTable.COL_ID + " integer primary key autoincrement, " +
                RecordDatabase.WeightTable.COL_WEIGHT + " real, " +
                RecordDatabase.WeightTable.COL_DATE + " int )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists " + RecordDatabase.WeightTable.TABLE);
        onCreate(db);
    }

    public Record addRecord(double weight){
        Date currDate = new Date();
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, weight);
        values.put(WeightTable.COL_DATE, currDate.getTime());

        long id = writeable.insert(WeightTable.TABLE, null, values);
        return new Record(id, weight, currDate );

    }

    public Record getRecord(long id){
        String[] columns = new String[] {
                WeightTable.COL_ID
        };

        String whereClause = WeightTable.COL_ID + " = ?";
        String[] whereArgs = new String[]{
                String.valueOf(id)
        };
        Cursor c = writeable.query(WeightTable.TABLE, columns, whereClause, whereArgs, null, null, null );

        try {
            if (c.moveToFirst()) {
                @SuppressLint("Range") double weightValue = c.getDouble(c.getColumnIndex(WeightTable.COL_WEIGHT));
                @SuppressLint("Range") Date dateValue = new Date(c.getInt(c.getColumnIndex(WeightTable.COL_DATE)));
                Record record = new Record(id, weightValue, dateValue);
                return record;
            } else {
                return null;
            }
        } catch (Exception e){
            Log.d(TAG, "Error while getting record");
        } finally {
            if (c!=null && !c.isClosed()){
                c.close();
            }
        }
        return null;
    }

    public void deleteRecord(long id) {
        writeable.delete(WeightTable.TABLE, WeightTable.COL_ID + " = ? ", new String[] { String.valueOf(id)});
    }

    public void editRecord(long id, double weight) {
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_WEIGHT, weight);

        String whereClause = WeightTable.COL_ID + " = ?";
        String[] whereArgs = new String[]{
                String.valueOf(id)
        };

        int ret = writeable.update(WeightTable.TABLE, values, whereClause, whereArgs );
        Log.e(TAG, String.valueOf(ret));
    }

    public List<Record> getRecords(){
        List<Record> result = new ArrayList<>();
        Cursor c = writeable.query(WeightTable.TABLE, null, null, null, null, null, String.valueOf(WeightTable.COL_DATE) );
        try {
            while(c.moveToNext()) {
                @SuppressLint("Range") Long id = c.getLong(c.getColumnIndex(WeightTable.COL_ID));
                @SuppressLint("Range") Long weightValue = c.getLong(c.getColumnIndex(WeightTable.COL_WEIGHT));
                @SuppressLint("Range") Date dateValue = new Date(c.getInt(c.getColumnIndex(WeightTable.COL_DATE)));
                Record record = new Record(id, weightValue, dateValue);
                result.add(record);
            }
        } catch (Exception e){
            Log.d(TAG, "Error while getting all records");
        } finally {
            if (c!=null && !c.isClosed()){
                c.close();
            }
        }
        return result;
    }


}
